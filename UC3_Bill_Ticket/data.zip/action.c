Action()
{

	lr_start_transaction("UC3_BillTicket");

	lr_start_transaction("01_OpenWebTours");

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_auto_header("Priority", 
		"u=0, i");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("01_OpenWebTours",LR_AUTO);

	lr_start_transaction("02_Login");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Priority", 
		"u=4");

	lr_think_time(16);

	web_submit_form("login.pl", 
		"Snapshot=t9.inf", 
		ITEMDATA, 
		"Name=username", "Value=user1", ENDITEM, 
		"Name=password", "Value=password1", ENDITEM, 
		LAST);

	lr_end_transaction("02_Login",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("03_OpenFlights");

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t10.inf", 
		LAST);

	lr_end_transaction("03_OpenFlights",LR_AUTO);

	web_add_auto_header("Origin", 
		"http://localhost:1080");

	lr_think_time(9);

	web_submit_form("reservations.pl", 
		"Snapshot=t11.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=09/28/2024", ENDITEM, 
		"Name=arrive", "Value=Frankfurt", ENDITEM, 
		"Name=returnDate", "Value=09/29/2024", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		LAST);

	lr_think_time(19);

	lr_start_transaction("04_SearchFlights");

	lr_end_transaction("04_SearchFlights",LR_AUTO);

	lr_start_transaction("05_SelectFlight");

	web_submit_form("reservations.pl_2", 
		"Snapshot=t12.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=013;315;09/28/2024", ENDITEM, 
		"Name=reserveFlights.x", "Value=65", ENDITEM, 
		"Name=reserveFlights.y", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("05_SelectFlight",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("06_PayForFlight");

	web_submit_form("reservations.pl_3", 
		"Snapshot=t13.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=name1", ENDITEM, 
		"Name=lastName", "Value=lastName1", ENDITEM, 
		"Name=address1", "Value=Place1", ENDITEM, 
		"Name=address2", "Value=Place1", ENDITEM, 
		"Name=pass1", "Value=name1 lastName1", ENDITEM, 
		"Name=creditCard", "Value=1223141324", ENDITEM, 
		"Name=expDate", "Value=11/33", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		LAST);

	lr_end_transaction("06_PayForFlight",LR_AUTO);

	lr_end_transaction("UC3_BillTicket",LR_AUTO);

	return 0;
}