Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_header("Priority", 
		"u=2");

	web_custom_request("XjA", 
		"URL=http://o.pki.goog/s/wr3/XjA", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\x12\\xABH\\xB9\\xB7c\\xDA~-\\x86\\xC3\\xDB\\xB3\\xC2w;)7-Z\\x04\\x14\\xC7\\x81\\xF5\\xFD\\x8E\\x88\\xD9\\x00<Mc\\xA2P1$\\xA0\\xCE#\\xFE#\\x02\\x10^0:\\x03\\xA5\\x8A\\xBFB\t:\\xE3\\xD0\\x9E\\xB39\\x8C", 
		LAST);

	lr_start_transaction("UC5_DelSel");

	lr_start_transaction("01_OpenWebTours");

	web_add_auto_header("Priority", 
		"u=4");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(15);

	web_url("header.html", 
		"URL=http://localhost:1080/WebTours/header.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("01_OpenWebTours",LR_AUTO);

	lr_start_transaction("02_Login");

	return 0;
}